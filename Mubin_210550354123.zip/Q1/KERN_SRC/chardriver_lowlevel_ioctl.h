#define TYPE 'x'
#define FGETIO  _IOR(TYPE,0,int)
#define FSETIO  _IOW(TYPE,1,int)
